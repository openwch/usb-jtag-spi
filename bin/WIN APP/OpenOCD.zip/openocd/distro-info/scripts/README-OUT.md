# The xPack OpenOCD

The **xPack OpenOCD** (formerly GNU MCU Eclipse OpenOCD)
is is the **xPack** version of **OpenOCD**,
an open-source project.

For more details, please read the corresponding release pages:

- <https://xpack.github.io/openocd/releases/>
- <http://openocd.org>

Thank you for using open source software,

Liviu Ionescu
